from __future__ import annotations
from typing import Any, Mapping

ACTIVE_DISCOVERY_ADVISORY_CONTRACT = "DOR-ISGN-ACTIVE-DISCOVERY-ADVISORY/1.0"


def build_active_discovery_advisory(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Convert an ISGN Active Discovery artifact into DOR *planning-only* advisory evidence.

    The adapter intentionally never upgrades posterior mass, VoI, predictive adequacy, or a proposed
    mechanism to a DOR physical identification or root-cause claim.  Those require the existing
    certified ISGN differential/completion contracts after an independently qualified mechanism is built.
    """
    tq = payload.get("truth_quarantine") if isinstance(payload.get("truth_quarantine"), Mapping) else {}
    truth_allowed = bool(payload.get("truth_channels_allowed", False) or tq.get("truth_channels_allowed", False)
                         or tq.get("held_out_truth_loaded", False) or tq.get("true_structure_loaded", False))
    status = "BLOCKED" if truth_allowed else "ADVISORY_ONLY"
    structures = payload.get("structure_posterior") if isinstance(payload.get("structure_posterior"), Mapping) else {}
    ranked = sorted(((str(k), float(v)) for k, v in structures.items()), key=lambda kv: -kv[1])
    ident = payload.get("identifiability") or payload.get("identifiability_decision")
    ident = ident if isinstance(ident, Mapping) else {}
    stability = payload.get("evidence_stability")
    stability = stability if isinstance(stability, Mapping) else {}
    return {
        "contract": ACTIVE_DISCOVERY_ADVISORY_CONTRACT,
        "status": status,
        "candidate_structures": [{"structure_id": k, "posterior_mass": v} for k, v in ranked],
        "next_experiment": payload.get("next_experiment") or payload.get("experiment_recommendation"),
        "predictive_adequacy": payload.get("predictive_adequacy"),
        "identifiability_status": ident.get("status"),
        "evidence_stability_status": stability.get("status"),
        "remaining_discriminating_experiments": ident.get("remaining_discriminating_experiments", []),
        "safety": {
            "truth_channels_allowed": False,
            "diagnostic_claim_allowed": False,
            "fault_identification_allowed": False,
            "root_cause_claim_allowed": False,
            "mechanism_identity_certified": False,
            "proposal_is_evidence": False,
        },
        "reason": (
            "active-discovery artifact touched hidden/held-out truth before DOR admission"
            if truth_allowed else
            "ISGN Active Discovery is planning evidence only; mechanism identity requires the existing ISGN certification/differential path"
        ),
    }
