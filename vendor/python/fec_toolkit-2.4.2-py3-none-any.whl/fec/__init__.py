"""FEC — Fractal Evidence Clamping / PHM Evidence Substrate."""

__version__ = "2.4.2"
